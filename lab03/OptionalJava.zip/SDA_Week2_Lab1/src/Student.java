import java.util.Optional;

public class Student {

	private String name;
	private int age;
	private Optional<Address> address;
	private Optional<Course> course;

	public Student(String name, int age, Address address, Course course) {
		this(name, age);
		this.address = Optional.ofNullable(address);
		this.course = Optional.ofNullable(course);
	}

	public Student(String name, int age) {
		this.name = name;
		this.age = age;
		this.address = Optional.empty();
		this.course = Optional.empty();
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(String.format("Name:%s Age:%d", name, age));
		
		if (address.isPresent()) {
			sb.append(' ');

			sb.append(address.get());
		}
		if (course.isPresent()) {

			sb.append(course.get());

		}

		return sb.toString();
	}

}
